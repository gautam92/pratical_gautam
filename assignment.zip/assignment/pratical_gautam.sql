-- Adminer 4.0.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+05:30';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1,	'2022-10-20-030933',	'App\\Database\\Migrations\\User',	'default',	'App',	1666236205,	1);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `password` varchar(500) NOT NULL,
  `profile_picture` varchar(250) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `gender`, `password`, `profile_picture`, `birth_date`, `created_at`, `updated_at`) VALUES
(1,	'Gautam',	'Dharaiya',	'gautamdharaiya@gmail.com',	NULL,	'$2y$10$sdX5AXj4H1./svhVkeyqp.VKfCIE9o8V84mKNyz63qS0C64idgnmO',	NULL,	NULL,	'2023-01-02 10:53:25',	'2023-01-02 10:53:25');

-- 2023-01-03 12:20:21
